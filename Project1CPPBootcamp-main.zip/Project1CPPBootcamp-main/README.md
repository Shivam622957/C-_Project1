
# MATRIX PUZZLE



## Run Locally

Clone the project

```bash
  git clone https://github.com/addy123d/matrix-puzzle.git
```


## Challenge

1. Make the better version of this game.
2. Send me a pull request :)
3. Tag me in your social media posts or stories (Not compulsory😅, but if you want to !)


## Feedback

If you have any feedback, please reach out to me at adityachaudhary@ineuron.ai

Follow me on Instagram [Aditya Chaudhary](https://www.instagram.com/addy__242)

